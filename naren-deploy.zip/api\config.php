<?php
// Real config — gitignored, never commit this file.
return [
    'from_email' => 'noreply@narengroups.com',
    'from_name'  => 'Naren Groups Website',
    'to_email'   => 'support@sunsys.in',
];
