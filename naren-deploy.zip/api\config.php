<?php
// Real SMTP credentials — gitignored, never commit this file.
return [
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_user' => 'sunsys06@gmail.com',
    'smtp_pass' => 'mofxuzivfqadncfs',
    'to_email'  => 'support@sunsys.in',
];
